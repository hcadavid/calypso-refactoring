
#' Calculate test statistic for ANCOM
#' 
#' @description
#' Calculates test statistics for differences in OTU abundances between treatment groups.
#' 
#' @param otu_data the OTU dataset.
#' @param n_otu the number of OTUs.
#' @param alpha the significance level at which the tests are to be performed.
#' @param multcorr type of correction for multiple comparisons, see Details.
#' @param Wexact logical, should Wilcoxon tests return exact p-values?
#' @param ncore if ncore>1, then \pkg{doParallel} will be loaded and used.
#' 
#' @details
#' \code{multcorr} can take on values of 1 (no correction), 2 (a less stringent)
#' correction, or 3 (a more stringent correction).
#' 
#' @note
#' This function is intended to be called by \code{\link{ANCOM}}, see the documentation of
#' that function for details on using the method.
#' 
#' @importFrom doParallel registerDoParallel
#' @importFrom foreach foreach
#' @importFrom coin kruskal_test
#' @importMethodsFrom coin pvalue
#' 
#' @export
#' 
#' 

ancom.detect <- function(otu_data, n_otu, alpha, multcorr, ncore){
  
  Group <- otu_data[,ncol(otu_data)]
  
  ## Parallelized way to get the logratio.mat
  ## Doubles the number of computations to make, so only run the parallel
  ## version if there are multiple cores. Method may also add some computational
  ## overhead, so if only 2 cores, the nested for-loop shoud have advantage
  ## over the parallel loop (though I have not tested that).
  ## For some reason this is taking much longer, do not run the parallel loop as of now.
  if( FALSE ){
    registerDoParallel( cores=ncore )
  
    aa <- bb <- NULL
    logratio.mat <- foreach( bb = 1:n_otu, .combine='rbind', .packages="foreach" ) %:% 
      foreach( aa = 1:n_otu , .combine='c',  .packages="foreach" ) %dopar% {
        if( aa==bb ){
          p_out <- NA
        } else{
          data.pair <- otu_data[,c(aa,bb,n_otu+1)]
          lr <- log((0.001+as.numeric(data.pair[,1]))/(0.001+as.numeric(data.pair[,2])))
          lr_dat <- data.frame( lr=lr, Group=Group )
                    
          p_out <- pvalue( kruskal_test(lr ~ Group, data = lr_dat,
                                        distribution = "asymptotic") )
        }
        p_out
    }
    rownames(logratio.mat) <- colnames(logratio.mat) <- NULL
  } else{
    logratio.mat <- matrix(NA, nrow=n_otu, ncol=n_otu)
    for(ii in 1:(n_otu-1)){
      for(jj in (ii+1):n_otu){
        data.pair <- otu_data[,c(ii,jj,n_otu+1)]
        lr <- log((0.001+as.numeric(data.pair[,1]))/(0.001+as.numeric(data.pair[,2])))
        lr_dat <- data.frame( lr=lr, Group=Group )
        
        logratio.mat[ii,jj] <- pvalue( kruskal_test(lr ~ Group, data = lr_dat,
                                                    distribution = "asymptotic") )
        
        #logratio.mat[ii,jj] <- wilcox.exact(lr[data.pair$grp==unique(data.pair$grp)[1]],
        #                                  lr[data.pair$grp==unique(data.pair$grp)[2]],
        #                                  exact=Wexact)$p.value
        # logratio.mat[ii,jj] <- t.test(lr[data.pair$grp==unique(data.pair$grp)[1]],
        #                          lr[data.pair$grp==unique(data.pair$grp)[2]])$p.value
        # logratio.mat[ii,jj] <- ks.test(lr[data.pair$grp==unique(data.pair$grp)[1]],
        #                           lr[data.pair$grp==unique(data.pair$grp)[2]])$p.value
      }
    }  
    ind <- lower.tri(logratio.mat)
    logratio.mat[ind] <- t(logratio.mat)[ind]
  }

  logratio.mat[which(is.finite(logratio.mat)==FALSE)] <- 1
  
  mc.pval <- t(apply(logratio.mat,1,function(x){
    s <- p.adjust(x, method = "BH")
    return(s)
  }))
  
  a <- logratio.mat[upper.tri(logratio.mat,diag=FALSE)==TRUE]
  
  b <- matrix(0,ncol=n_otu,nrow=n_otu)
  b[upper.tri(b)==T] <- p.adjust(a, method = "BH")
  diag(b)  <- NA
  ind.1    <- lower.tri(b)
  b[ind.1] <- t(b)[ind.1]
  
  if(multcorr==1){
    W <- apply(b,1,function(x){
      subp <- length(which(x<alpha))
    })
  } else if(multcorr==2){
    W <- apply(mc.pval,1,function(x){
      subp <- length(which(x<alpha))
    })
  } else if(multcorr==3){
    W <- apply(logratio.mat,1,function(x){
      subp <- length(which(x<alpha))
    })
  }
  return(W)
}

############################################################
############################################################


#' Run the ANCOM method
#' 
#' @description
#' Runs ANCOM to test for differences in OTU abundances between treatment groups.
#' 
#' @param real.data the OTU dataset. See Details for formatting instructions.
#' @param sig the significance level (or FDR) at which the tests are to be performed.
#' @param multcorr type of correction for multiple comparisons, see Details.
#' @param tau a tuning parameter in the Stepwise testing method. See Details.
#' @param theta a tuning parameter in the Stepwise testing method. See Details.
#' 
#' @details
#' The ANCOM method was developed and tested with default values of the two tuning parameters 
#' (\code{tau=0.02} and \code{theta=0.1}). For consistency, users are recommended to leave 
#' these tuning parameters at their default values, unless they wish to explore the performance
#'  of ANCOM for different values of the tuning parameters.
#' 
#' Data should be formatted as follows: each row is a subject, and each column is an OTU.
#' The final column should contain the grouping variable.
#' 
#' To adjust for multiple testing, \code{multcorr} may take on the following values:
#' \itemize{
#' \item{ \code{1}: }{ A stringent correction}
#' \item{ \code{2}: }{ A less stringent correction}
#' \item{ \code{3}: }{ No correction (default)}
#' }
#' The more stringent correction is not available in the shiny application.
#' 
#' @note
#' The function \code{\link{plot_ancom}} will produce plots for objects produced by \code{ANCOM}.
#' 
#' @return
#' The function produces a list with the following elements:
#' \itemize{
#' \item{ \code{W}: }{ values of the test statistics.}
#' \item{ \code{detected}: }{ names of OTUs detected.}
#' \item{ \code{dframe}: }{ the input dataframe.}
#' }
#'  
#' @export
#' 
#' @examples
#' 
#' \dontrun{
#' ## Create and run a small example
#' 
#' nn <- 10
#' pp <- 20
#' sim_otu <- matrix( 0, nrow=nn, ncol=pp+1 )
#' sim_otu <- data.frame(sim_otu)
#' colnames(sim_otu) <- c( paste0("OTU_", letters[1:pp] ), "Group" )
#' sim_otu[,pp+1]    <- c( rep("Control",nn/2), rep("Treatment",nn/2)  )
#' idx_trt <- sim_otu$Group=="Treatment"
#' 
#' for( ii in 1:pp ){
#'   sim_otu[,ii] <- rpois( nn, 1 )
#' }
#' 
#' # Create some significance
#' sim_otu[idx_trt,3] <- rpois( nn/2, 8)
#' sim_otu[idx_trt,7] <- rpois( nn/2, 8)
#' sim_otu[idx_trt,9] <- rpois( nn/2, 8)
#' 
#' ancom.out <- ANCOM( real.data = sim_otu, sig = 0.20, multcorr = 2 )
#' ancom.out$W
#' ancom.out$detected
#' }
#' 

ANCOM  <-  function(real.data, sig=0.05, multcorr=3, tau=0.02, theta=0.1 ){
  
  #real.data <-  read.delim(filepath,header=TRUE)
  colnames(real.data)[dim(real.data)[2]] <- "Group"
  real.data$Group <- factor( real.data$Group )
  real.data       <- data.frame(real.data[which(is.na(real.data$Group)==F),],row.names=NULL)
  num_OTU         <- ncol(real.data) - 1
  
  W.detected <- ancom.detect(real.data, num_OTU, sig, multcorr, ncore=1 )
  W_stat     <- W.detected
  
  
  ## Per Shyamal (June 4, 2015): 
  ##  If number of OTUs is < 10, then use 'arbitrary' method, reject Ho if 
  ##  W > p - 1, where p = number of OTUs. If number of OTUs > 10, then use
  ##  the stepwise method. Consequently, only one output will be produced,
  ##  instead of detected_arbitrary and detected_stepwise, produce "detected"
  ## Rephrase "arbitrary", since it's not arbitrary, more of an empirical method.
  
  ## Detected using arbitrary cutoff
  # Previous code:
  # detected_arbitrary <- colnames(real.data)[ which( W.detected > num_OTU*theta ) ]
  
  if( num_OTU < 10 ){
    detected <- colnames(real.data)[which(W.detected > num_OTU-1 )]    
  } else{
    ## Detected using a stepwise mode detection
    if( max(W.detected)/num_OTU >= theta ){
      c.start <- max(W.detected)/num_OTU
      cutoff  <- c.start-c(0.05,0.10,0.15,0.20,0.25)
      
      prop_cut <- rep(0,length(cutoff))
      for(cut in 1:length(cutoff)){
        prop_cut[cut] <- length(which(W.detected>=num_OTU*cutoff[cut]))/length(W.detected)
      } 
      
      del <- rep(0,length(cutoff)-1)
      for( ii in 1:(length(cutoff)-1) ){
        del[ii] <- abs(prop_cut[ii]-prop_cut[ii+1])
      }
      
      if(       del[1]< tau & del[2]<tau & del[3]<tau ){ nu=cutoff[1]
      }else if( del[1]>=tau & del[2]<tau & del[3]<tau ){ nu=cutoff[2]
      }else if( del[2]>=tau & del[3]<tau & del[4]<tau ){ nu=cutoff[3]                                
      }else{ nu=cutoff[4] }
      
      up_point <- min(W.detected[ which( W.detected >= nu*num_OTU ) ])
      
      W.detected[W.detected>=up_point] <- 99999
      W.detected[W.detected<up_point]  <- 0
      W.detected[W.detected==99999]    <- 1
      
      detected <- colnames(real.data)[which(W.detected==1)]
      
    } else{
      W.detected <- 0
      detected   <- "No significant OTUs detected"
    }
    
  }
  
  #results_list <- list( W         = W_stat,
  #                      Arbitrary = detected_arbitrary,
  #                      Stepwise  = detected_stepwise )
  #idx0 <- lapply( results_list , FUN=length)
  #results_list[idx0==0] <- "No significant OTUs detected"
  
  results <- list( W=W_stat, detected=detected, dframe=real.data )
  class(results) <- "ancom"
  
  return(results)  
  
}
#########################################################################





