#! /usr/bin/env perl
use strict;
use warnings;
use Getopt::Std;

sub clean_handler{
    die;
}

########
# check arguments
########
sub check_args{
    my ($n) = @_;

    if(@ARGV!= $n){
	usage();
	print STDERR "ERROR: wrong number of arguments, number of expected arguments: $n\n";
	exit 1;
    }

    return 1;
}

##########
# convert qiime otu table 
##########
sub convert_otu_table{
    my ($otu_table,$out,$uclust_ref) = @_;


    my %species = ();

    # if otus were generated using uclust_ref
    if($uclust_ref){
	# get matching reference sequences
	print STDERR "Parsing file $otu_table ...";
	die unless open(OT,"<$otu_table");
	my $line;
	my %matching = ();
	while($line = <OT>){
	    	next if $line =~ /^\s*\#OTU/;
		next if $line =~ /^\s*$/;
		next if $line =~ /^\s*\#/;
		chomp($line);

		my @fields = split(/\s*\t\s*/,$line);
		my $otu = shift @fields;

		# check if OTU was generated based on matching reference 
		# sequence
		if(! ($otu =~ /^None\d/)){
		    $matching{$otu} = 1;
		}

	}
	close(OT);
	print STDERR " Done.\n";

	# parse reference fasta file and get species of matching
	# reference sequences
	my $sub_ref = sub{
	    my ($name) = @_;

	    my @fields = split(/\s+/,$name);
	    my $id = $fields[0];

	    return 1 unless defined $matching{$id};

	    my $genus = $fields[1] || "";
	    my $sp = $fields[2] || "";

	    $species{$id} = "$genus $sp";

	    return 1;
	};

	die unless parse_fasta($uclust_ref,$sub_ref);

	%matching = ();
    }

    die "ERROR: Could not open file $otu_table: $!\n" unless open(TA,"<$otu_table");
    die "ERROR: Could not open file $out: $!\n" unless open(CA,">$out");

    my $line;

    # get header
    while($line = <TA>){

	next unless $line =~ /^\s*\#OTU/;

	chomp($line);
	my @header = split(/\t/,$line);
	shift @header;
	pop @header;
	print CA "OTU,Header,", join(',',@header),"\n";
	last;
    }

    # get taxa counts
    while($line = <TA>){
	next if $line =~ /^\s*$/;
	next if $line =~ /^\s*\#/;
	chomp($line);

	my @fields = split(/\s*\t\s*/,$line);
	my $otu = shift @fields;
	my $taxa = pop @fields;
	my $id;
	my $id_set = 0;

	if($uclust_ref){
	    if(! ($otu =~ /^None/)){
		my $spec = $species{$otu};
		die "ERROR: no species for $otu ($uclust_ref)\n" unless $spec;
		$id = "$spec $otu";
		$id_set =1;
	    }
	}
	
	if(! $id_set){
	    
	
	my @tmp = split(/\;/,$taxa);

	if(@tmp > 1){
	    shift @tmp;
	    $taxa = join(';',@tmp);

	    if(@tmp > 2){
		my $phylum = shift @tmp;
		my $last = pop @tmp;
		$taxa = "$phylum;$last";
	    }
	}

	$id = "$taxa $otu";
	}


	print CA "OTU,$id," , join(',',@fields) , "\n";
    }

    close(TA);
    close(CA);

    return 1;
}

##########
# convert qiime mapping file
##########
sub convert_mapping{
    my ($mapping,$out) = @_;

    die "ERROR: Could not open file $mapping: $!\n" unless open(MA,"<$mapping");
    die "ERROR: Could not open file $out: $!\n" unless open(AN,">$out");


    print AN "#Sample,Label,Individual,Group,Time,Include\n";
    my $line;

    my $indiv = 1;
    while($line = <MA>){
	next if $line =~ /^\s*$/;
	next if $line =~ /^\s*\#/;
	chomp($line);
	$line =~ s/\s*$//;

	my @fields = split(/\s*\t\s*/,$line);
	my $sample = $fields[0];
	my $descr = pop @fields;

	# sampleID, label, subject, group, time point/location, Response, Include
	print AN "$sample,$sample,$indiv,$descr,1,0,1\n";
	$indiv++;
    }

    close(MA);
    close(AN);

    return 1;
}

##########
# convert assign_taxonomy.pl output 
##########
sub convert_assign_tax{
    my ($assignment,$out) = @_;


    die "ERROR: Could not open file $assignment: $!\n" unless open(MA,"<$assignment");

    my $line;

    my %counts = ();
    my %samples = ();

    my %total = ();
    my %assigned = ();

    while($line = <MA>){
	next if $line =~ /^\s*$/;
	next if $line =~ /^\s*\#/;
	chomp($line);

	my @fields = split(/\s+/,$line);
	my $sample = $fields[0];
	my $conf = pop @fields;
	my $taxa = pop @fields;

	my @tmp = split(/\_/,$sample);
	pop @tmp;
	$sample = join('_',@tmp);

	$samples{$sample} = 1;

	$total{$sample}++;

	my @ta = split(';',$taxa);

	my $level = 0;

	if(@ta > 6){
	    die "ERROR: $taxa\n";
	}

	foreach my $t (@ta){
	    $counts{$level}{$t}{$sample}++;
	    $assigned{$level}{$sample}++;
	    $level++;
	}
    }

    close(MA);

    my %ranks = (
	0 => 'Domain',
	1 => 'Phylum',
	2 => 'Class',
	3 => 'Order',
	4 => 'Family',
	5 => 'Genus'
	);

    my @samples = keys %samples;
    my $samples = join(',',@samples);

    die "ERROR: Could not open file $out: $!\n" unless open(AN,">$out");
    
    foreach my $level (sort {$a <=> $b} keys %counts){

	my $rank = $ranks{$level};
	
	die "ERROR: No rank for level $level\n" unless $rank;

	print AN "$rank,Header,$samples\n";
	
	foreach my $taxa (keys %{$counts{$level}}){
	    
	    $taxa = "${rank}_$taxa" if(lc($taxa) eq "unclassified");

	    print AN "$rank,$taxa";

	    foreach my $sample (@samples){
		my $count = $counts{$level}{$taxa}{$sample} || 0;
		print AN ",$count";
	    }
	    print AN "\n";
	}
	# add unclassified
	print AN "$rank,Unclassified";
	
	foreach my $sample (@samples){
	    my $tot = $total{$sample};
	    die unless $tot;
	    my $classified = $assigned{$level}{$sample} || 0;

	    my $unclassified = $tot - $classified;
	    print AN ",$unclassified";
	}
       
	print AN "\n\n";
    }

    close(AN);

    return 1;
}

##########
# parse fasta file
##########
sub parse_fasta{
    my $file = shift @_;
    my $subref = shift @_;
    my @args = @_;
    
    print STDERR "Parsing file $file ... ";
    unless(open (FASTA, "<$file")){
	print STDERR "ERROR: parse_fasta: Could not open $file:$!\n"; 
	return;
    }

    my ($name,$sequence);
    
    # read each line in fasta file and process entrys
    # 
    my $line;

    while ($line = <FASTA>) {
	chomp($line);
	next if $line =~ /^\s*$/;
	next if $line =~ /^\s*\#/;

	$line =~ s/\s+$//;

	# check if line contains new fasta header
	if ($line =~ /^>\s*(.+)/) {

	    # process fasta sequence
	    if ($name) {
		&$subref($name,$sequence,@args) or return;
	    }
	    # new entry in fasta file read, therfor set sequence to empty string
	    $name = $1;
	    $sequence = "";
	}
	# line contains DNA sequence, append to $sequence
	else {
	    $sequence .= $line;
	}
    }
    
    # process fasta sequence
    if ($name) {
	&$subref($name,$sequence,@args) or return;
    }
    close (FASTA);
    print STDERR " Done.\n";

    return 1;
}


##
# usage message
##
sub usage{
    print <<USAGE;

  $0 

  Convert QIIME otu table to calypso counts file:
  ===============================================

  $0 -o [options] <otu_table>  <output>

 where:
  <otu_table> QIIME OTU table. OTU tables are generated 
              with the QIIME script pick_otu_table.py
  <output>    file name for the output of $0

 Options:
  -r <fasta> ucluct reference sequences if OTUs were picked with uclust

  Example: $0 -o otus/otu_table.txt   calypso.csv


  Convert QIIME assign_taxonomy.py output to calypso counts file:
  ===============================================================

  $0 -t <tax_assignments>  <output>
  
 where:
  <tax_assigments> assign_taxonomy.py output file
  <output>         output file name

  Example: $0 -t rdp22_assigned_taxonomy/seqs_tax_assignments.txt   calypso.csv




  Convert QIIME mapping file to calypso annotation file:
  ======================================================

  $0 -m <mapping_file> <output>

 where:
  <maping_file> QIIME mapipng file
  <output>      name of output file

  Example: $0 -m mapping.txt   calypso.annotation.csv

  Example mapping file:
  ----------------------
  #SampleID       BarcodeSequence LinkerPrimerSequence Group  Description
  Sample49        CAGTACGT        acgggcggtgtgtRc normal        control
  Sample50        CATAGCAT        acgggcggtgtgtRc normal        control
  Sample51        CGAGATGT        acgggcggtgtgtRc normal        control
  Sample55        AGAGATGAT       acgggcggtgtgtRc diabetic        fat
  Sample56        AGATCGTAT       acgggcggtgtgtRc diabetic        fat
  Sample57        AGATGACGT       acgggcggtgtgtRc diabetic        fat
 
  For more details on QIIME mapping files see: http://www.qiime.org/tutorials/tutorial.html

USAGE

}


##
# Get parameters
## 
our($opt_v,$opt_h,$opt_o,$opt_m,$opt_t,$opt_r);

getopts("vhomtr:");

unless(@ARGV){
    usage;
    exit 1;
}


my @files = @ARGV;

if($opt_h){
    usage;
    exit;
    
}
elsif($opt_o){
    check_args(2);
    my ($otu_table,$out) = @ARGV;
    exit 1 unless convert_otu_table($otu_table,$out,$opt_r);
}
elsif($opt_t){
    check_args(2);
    my ($assignment,$out) = @ARGV;
    exit 1 unless convert_assign_tax($assignment,$out);
}
elsif($opt_m){
    check_args(2);
    my ($mapping,$out) = @ARGV;
    exit 1 unless convert_mapping($mapping,$out);
}

else{
    usage;
}
